@echo off
rem GhostIDE one-command install (Windows): copies the app
rem to %LOCALAPPDATA%\GhostIDE and adds a Start Menu shortcut.
setlocal
set "SRC=%~dp0"
set "DEST=%LOCALAPPDATA%\GhostIDE"
mkdir "%DEST%" 2>nul
xcopy /E /Y /Q "%SRC%*" "%DEST%\" >nul
powershell -NoProfile -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut([IO.Path]::Combine($env:APPDATA,'Microsoft\Windows\Start Menu\Programs\GhostIDE.lnk')); $s.TargetPath=Join-Path $env:LOCALAPPDATA 'GhostIDE\GhostIDE.exe'; $s.Save()"
echo GhostIDE installed. Find GhostIDE in the Start Menu.
echo It opens at http://127.0.0.1:5173 with a workspace in %USERPROFILE%\GhostIDE.
pause
