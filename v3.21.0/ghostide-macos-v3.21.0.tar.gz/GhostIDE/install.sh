#!/usr/bin/env bash
# GhostIDE one-command install (macOS): copies the app to
# ~/Applications/GhostIDE and a launcher to /usr/local/bin
# when writable, else ~/bin.
set -euo pipefail
SRC="$(cd "$(dirname "$0")" && pwd)"
DEST="$HOME/Applications/GhostIDE"
mkdir -p "$DEST"
cp -a "$SRC/." "$DEST/"
chmod +x "$DEST/GhostIDE"
echo "GhostIDE installed to $DEST"
echo "Run it with:  $DEST/GhostIDE"
echo "It opens at http://127.0.0.1:5173 with a workspace in ~/GhostIDE."
